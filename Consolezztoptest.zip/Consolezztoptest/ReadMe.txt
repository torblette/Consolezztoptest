﻿
This project was created as part of a take home assignement for an interview

===============
Exercise 1: SQL
===============

Write a SQL query that retrieves every person and their most recent order (if one exists).  

Create and populate the following tables

CREATE TABLE [dbo].[Person](
	[PersonId] [bigint] IDENTITY(500,1) NOT NULL,
	[NameFirst] [varchar](150) NULL,
	[NameLast] [varchar](50) NULL
 CONSTRAINT [PK_Person] PRIMARY KEY CLUSTERED 
(
	[PersonId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

CREATE TABLE [dbo].[Orders](
	[OrderId] [bigint] IDENTITY(9000,1) NOT NULL,
	[PersonId] [bigint] NOT NULL,
	[OrderDateTime] [datetime] NOT NULL
 CONSTRAINT [PK_Order] PRIMARY KEY CLUSTERED 
(
	[OrderId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

CREATE TABLE [dbo].[BackOrders](
	[BackOrderId] [bigint] IDENTITY(500,1) NOT NULL,
	[OrderId] [bigint] NOT NULL,
	[BackOrderDateTime] [datetime] NOT NULL,
 CONSTRAINT [PK_BackOrder] PRIMARY KEY CLUSTERED 
(
	[BackOrderId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO


insert into person (NameFirst,NameLast) values ('Rebeka','Muller')
insert into person (NameFirst,NameLast) values ('Paul','Thompson')
insert into person (NameFirst,NameLast) values ('Mark','Smith')
insert into person (NameFirst,NameLast) values ('Sarah','Strazinski')

insert into orders (PersonId,OrderDateTime) values (500,'2016-10-12 08:15')
insert into orders (PersonId,OrderDateTime) values (502,'2016-10-12 10:30')
insert into orders (PersonId,OrderDateTime) values (503,'2016-10-12 15:45')
insert into orders (PersonId,OrderDateTime) values (503,'2016-10-01 09:00')

INSERT [dbo].[BackOrders] ([BackOrderId], [OrderId], [BackOrderDateTime]) VALUES (500, 9001, CAST(N'2016-12-11 14:27:27.380' AS DateTime))
GO

-------------
Other table information

Table Person
exec sp_columns Person

TABLE_NAME	COLUMN_NAME	DATA_TYPE	TYPE_NAME
Person		PersonId	-5			bigint identity
Person		NameFirst	12			varchar
Person		NameLast	12			varchar

Table Orders
exec sp_columns Orders

TABLE_NAME	COLUMN_NAME		DATA_TYPE	TYPE_NAME
Orders		OrderId			-5			bigint identity
Orders		PersonId		-5			bigint
Orders		OrderDateTime	11			datetime

Table BackOrders
exec sp_columns BackOrders

TABLE_NAME	COLUMN_NAME			DATA_TYPE	TYPE_NAME
BackOrders	BackOrderId			-5			bigint identity
BackOrders	OrderId				-5			bigint
BackOrders	BackOrderDateTime	11			datetime


Query:
Note: Partitioning may improve efficiency, but did not try it.

SELECT 
	P.PersonId,
	P.NameFirst,
	P.NameLast,
	O2.OrderId AS LastOrderID,
	O.LastOrderDateTime
FROM
	Person P
		LEFT JOIN 
			(SELECT PersonId, MAX(OrderDateTime) AS LastOrderDateTime FROM Orders GROUP BY PersonId) O ON P.PersonId = O.PersonId
		LEFT JOIN Orders O2 ON O.LastOrderDateTime = O2.OrderDateTime
ORDER BY
	O.LastOrderDateTime DESC

Query Results:
PersonId	NameFirst	NameLast	LastOrderID	LastOrderDateTime
503			Sarah		Strazinski	9002		2016-10-12 15:45:00.000
502			Mark		Smith		9001		2016-10-12 10:30:00.000
500			Rebeka		Muller		9000		2016-10-12 08:15:00.000
501			Paul		Thompson	NULL		NULL


Extra:
Create a query to get back orders, if they exist

SELECT 
	BO.backorderid, BO.orderid, BO.backorderdatetime
FROM BackOrders BO
	LEFT JOIN Orders O on BO.orderid = O.OrderId
	LEFT JOIN Person P on O.PersonId = P.PersonId
WHERE
	P.PersonId = 502 



===============
Exercise 2: C#
===============

Write a data access method that takes a date as a parameter, calls a stored procedure (which returns all persons with orders for a specified date) and returns the results as a list of Person objects 


•	Input will be a valid date;  10/12/2016, for example that will be validated and turned into a SQL datetime of 2016-10-12
•	The SP will take a FromDate and a ToDate with a time string appended to the date to span the full day; '2016-10-12 00:00' to '2016-10-12 23:59'
•	Returned JSON since it can be used in various ways – I kept the order information available as I felt it was useful
•	Connection string was hard coded for expediency



CREATE PROCEDURE [dbo].[sp_GetPersonOrders] 
	@DateFrom varchar(20),
	@DateTo varchar(20)
AS
BEGIN
	SET NOCOUNT ON;

	SELECT 
		P.PersonId,
		P.NameFirst,
		P.NameLast,
		O.OrderId,
		O.OrderDateTime
	FROM
		Person P
			LEFT JOIN Orders O ON P.PersonId = O.PersonId
	WHERE
		OrderDateTime > @DateFrom AND OrderDateTime < @DateTo 
	ORDER BY
		O.OrderDateTime DESC
END
GO

GRANT EXECUTE ON OBJECT::[dbo].[sp_GetPersonOrders] TO [localapp] AS [dbo]

exec sp_GetPersonOrders '2016-10-12 00:00', '2016-10-12 23:59'


===============
Exercise 3: OOP  
===============

Please provide the exact console  output  of the following program.  Please provide an explanation of your answer.  

See Program.cs for the code

•	MusicalIstrument is the base class, so calling Play() on instrument2 will display “Playing an instrument.” as expected
•	For instrument1, the Play() method in the base class is virtual and can be overridden, extended. Therefore by putting “override” keyword/modifier on the Play() method in the Guitar class the return will be “Playing a guitar.”
•	For instrument3, the Play() method in the Piano class has the “new” keyword/modifier. This hides the console message in the Piano class and uses the base class console message of “Playing an instrument.”

Playing a guitar.
Playing an instrument.
Playing an instrument.