﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace Consolezztoptest
{
    public class Utilities
    {
        protected System.Web.Script.Serialization.JavaScriptSerializer serializer = new System.Web.Script.Serialization.JavaScriptSerializer();

        public string ConvertToJSON(object oObject)
        {
            Type otype = oObject.GetType();
            
            if (otype.Name.ToString().ToUpper() == "DATATABLE")
            {
                var datatable = oObject as DataTable;
                List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
                Dictionary<string, object> row;
                foreach (DataRow dr in datatable.Rows)
                {
                    row = new Dictionary<string, object>();
                    foreach (DataColumn col in datatable.Columns)
                    {
                        row.Add(col.ColumnName, dr[col]);
                    }
                    rows.Add(row);
                }

                return serializer.Serialize(rows);
            }
            else if (otype.Name.ToString().ToUpper().Contains("LIST"))
            {
                return serializer.Serialize(oObject);
            }


            return null;
        }
    }
}
