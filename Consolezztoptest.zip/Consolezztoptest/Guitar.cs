﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Consolezztoptest
{
    public class Guitar : MusicalInstrument
    {
        public override void Play()
        {
            //Console.Write("Playing a guitar.");
            Console.WriteLine("Playing a guitar.");
        }

    }
}
