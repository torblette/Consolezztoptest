﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Consolezztoptest
{
    public class Piano : MusicalInstrument
    {
        public new void Play()
        {
            //Console.Write("Playing a piano.");
            Console.WriteLine("Playing a piano.");
        }

    }
}
