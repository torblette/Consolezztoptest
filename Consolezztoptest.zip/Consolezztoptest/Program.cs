﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Consolezztoptest
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                // Exercise 1: SQL - See ReadMe.txt for database setup and queries
                Console.WriteLine("===================================================");
                Console.WriteLine("Exercise 1: SQL - See ReadMe.txt for database setup and queries");
                Console.WriteLine(" ");

                // Exercise 2: C# - Getting Person and Order data
                Console.WriteLine("===================================================");
                Console.WriteLine("Exercise 2: C# - Get person and order data via a stored procedure");
                Console.WriteLine(" ");
                GetData myData = new GetData();
                string strJsonData = myData.GetOrders("2016-10-12", "2016-10-12");
                Console.WriteLine("Result is unformatted JSON:");
                Console.WriteLine(strJsonData);

                Console.WriteLine(" ");
                Console.WriteLine("===================================================");
                Console.WriteLine("Exercise 3: OOP - Playing instruments");
                // Exercise 3: OOP - Playing instruments
                MusicalInstrument instrument1 = new Guitar();
                MusicalInstrument instrument2 = new MusicalInstrument();
                MusicalInstrument instrument3 = new Piano();
                instrument1.Play();
                instrument2.Play();
                instrument3.Play();
            }
            catch (Exception ex)
            {
                Console.WriteLine(string.Format("EXCEPTION: [{0}]", ex.Message));
            }
            finally
            {
                Console.ReadKey();
            }
        }
    }
}
