﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Data.SqlClient;
using System.Data.Sql;
using System.Text;
using System.Threading.Tasks;

namespace Consolezztoptest
{
    public class GetData
    {
        protected string connString = "Data Source=ORBLETTE-LAPTOP\\SQLEXPRESS2012;Initial Catalog=zz_toptest;User ID=localapp;Password=testapp";

        protected string sqlSP = "sp_GetPersonOrders";

        protected SqlConnection conn;

        public string GetOrders(string fromDate, string toDate)
        {
            DataTable dtOrders = new DataTable();
            Utilities uUtils = new Utilities();

            if (Open())
            {
                StringBuilder sbSP = new StringBuilder();

                sbSP.Append(sqlSP);
                sbSP.Append(" ");
                sbSP.Append(string.Format(" '{0} 00:00', ", fromDate));
                sbSP.Append(string.Format("'{0} 23:59'", toDate));


                using (SqlCommand cmd = new SqlCommand(sbSP.ToString(), conn))
                {
                    try
                    {
                        SqlDataAdapter sdaInvAdapter = new SqlDataAdapter(cmd);
                        sdaInvAdapter.Fill(dtOrders);
                        Close();

                        return uUtils.ConvertToJSON(dtOrders);

                    }
                    catch (Exception ex)
                    {
                        return ex.Message;
                    }
                }
            }
            else
            { return null; }
        }

        private bool Open(string stConnection = "SqlConnectionString")
        {
            conn = new SqlConnection(connString);

            try
            {
                if (conn.State.ToString().ToUpper() != "OPEN")
                {
                    conn.Open();
                }

                return true;
            }
            catch (SqlException ex)
            {
                return false;
                //throw ex;
            }
        }

        private bool Close()
        {
            try
            {
                conn.Close();
                return true;
            }
            catch (SqlException ex)
            {
                return false;
                //throw ex;
            }
        }
    }
}