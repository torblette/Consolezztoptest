﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Consolezztoptest
{
    public class MusicalInstrument
    {
        public virtual void Play()
        {
            //Console.Write("Playing an instrument.");
            Console.WriteLine("Playing an instrument.");
        }

    }
}
