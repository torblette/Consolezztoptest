CREATE PROCEDURE [dbo].[sp_GetPersonOrders] 
	@DateFrom varchar(20),
	@DateTo varchar(20)
AS
BEGIN
	SET NOCOUNT ON;

	SELECT 
		P.PersonId,
		P.NameFirst,
		P.NameLast,
		O.OrderId,
		O.OrderDateTime
	FROM
		Person P
			LEFT JOIN Orders O ON P.PersonId = O.PersonId
	WHERE
		OrderDateTime > @DateFrom AND OrderDateTime < @DateTo 
	ORDER BY
		O.OrderDateTime DESC
END
GO
/****** Object:  Table [dbo].[BackOrders]    Script Date: 12/18/2016 4:49:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[BackOrders](
	[BackOrderId] [bigint] IDENTITY(500,1) NOT NULL,
	[OrderId] [bigint] NOT NULL,
	[BackOrderDateTime] [datetime] NOT NULL,
 CONSTRAINT [PK_BackOrder] PRIMARY KEY CLUSTERED 
(
	[BackOrderId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[Orders]    Script Date: 12/18/2016 4:49:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Orders](
	[OrderId] [bigint] IDENTITY(9000,1) NOT NULL,
	[PersonId] [bigint] NOT NULL,
	[OrderDateTime] [datetime] NOT NULL,
 CONSTRAINT [PK_Order] PRIMARY KEY CLUSTERED 
(
	[OrderId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[Person]    Script Date: 12/18/2016 4:49:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Person](
	[PersonId] [bigint] IDENTITY(500,1) NOT NULL,
	[NameFirst] [varchar](150) NULL,
	[NameLast] [varchar](50) NULL,
 CONSTRAINT [PK_Person] PRIMARY KEY CLUSTERED 
(
	[PersonId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
SET IDENTITY_INSERT [dbo].[BackOrders] ON 

GO
INSERT [dbo].[BackOrders] ([BackOrderId], [OrderId], [BackOrderDateTime]) VALUES (500, 9001, CAST(N'2016-12-11 14:27:27.380' AS DateTime))
GO
SET IDENTITY_INSERT [dbo].[BackOrders] OFF
GO
SET IDENTITY_INSERT [dbo].[Orders] ON 

GO
INSERT [dbo].[Orders] ([OrderId], [PersonId], [OrderDateTime]) VALUES (9000, 500, CAST(N'2016-10-12 08:15:00.000' AS DateTime))
GO
INSERT [dbo].[Orders] ([OrderId], [PersonId], [OrderDateTime]) VALUES (9001, 502, CAST(N'2016-10-12 10:30:00.000' AS DateTime))
GO
INSERT [dbo].[Orders] ([OrderId], [PersonId], [OrderDateTime]) VALUES (9002, 503, CAST(N'2016-10-12 15:45:00.000' AS DateTime))
GO
INSERT [dbo].[Orders] ([OrderId], [PersonId], [OrderDateTime]) VALUES (9003, 503, CAST(N'2016-10-01 09:00:00.000' AS DateTime))
GO
SET IDENTITY_INSERT [dbo].[Orders] OFF
GO
SET IDENTITY_INSERT [dbo].[Person] ON 

GO
INSERT [dbo].[Person] ([PersonId], [NameFirst], [NameLast]) VALUES (500, N'Rebeka', N'Muller')
GO
INSERT [dbo].[Person] ([PersonId], [NameFirst], [NameLast]) VALUES (501, N'Paul', N'Thompson')
GO
INSERT [dbo].[Person] ([PersonId], [NameFirst], [NameLast]) VALUES (502, N'Mark', N'Smith')
GO
INSERT [dbo].[Person] ([PersonId], [NameFirst], [NameLast]) VALUES (503, N'Sarah', N'Strazinski')
GO
SET IDENTITY_INSERT [dbo].[Person] OFF
GO
